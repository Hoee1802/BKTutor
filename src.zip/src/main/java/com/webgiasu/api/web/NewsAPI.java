package com.webgiasu.api.web;

import org.springframework.web.bind.annotation.RestController;

@RestController(value = "newsAPIOfWeb") // biến nó thành một API
public class NewsAPI {

}
